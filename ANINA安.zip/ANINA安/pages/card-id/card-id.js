import QR from '../../utils/qrcode.js'
Page({
  data: {
    card_num: '',
    card_num_: ''
  },

  onLoad: function () {
    let card_num1 = wx.BaaS.storage.get('card_infor').card_id.substring(0, 3)
    let card_num2 = wx.BaaS.storage.get('card_infor').card_id.substring(3, 7)
    let card_num3 = wx.BaaS.storage.get('card_infor').card_id.substring(7, 11)
    let card_num = card_num1 + ' ' + card_num2 + ' ' + card_num3
    let card_num_ = wx.BaaS.storage.get('card_infor').card_id
    this.setData({
      card_num,
      card_num_
    })
  },
})