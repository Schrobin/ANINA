import QR from '../../utils/qrcode.js'
Page({
  data: {
    card_num: ''
  },

  onLoad: function () {
    let card_num1 = wx.BaaS.storage.get('card_infor').card_id.substring(0, 3)
    let card_num2 = wx.BaaS.storage.get('card_infor').card_id.substring(3, 7)
    let card_num3 = wx.BaaS.storage.get('card_infor').card_id.substring(7, 11)
    let card_num = card_num1 + ' ' + card_num2 + ' ' + card_num3
    
    this.setData({
      card_num
    })

    let card_num_ = wx.BaaS.storage.get('card_infor').card_id
    console.log(card_num_)
    this.getCode(card_num_)
    // this.createQrCode(card_num_, 200, 200)
  },

  getCode: function(card_num){
   
  }

})