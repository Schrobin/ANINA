
Page({

  code:function(){
    var getcode = require('../../utils/code')
    var data = getcode.createQrCodeImg('18535911335',{'size':300});
    console.log(data);
    var img = document.getElementById('img');
    img.setAttribute('src',data);
  }

})