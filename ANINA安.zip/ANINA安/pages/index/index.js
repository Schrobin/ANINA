//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    isPlay1: 'none',
    isPlay2: 'none',
    card_id: '',
    scope: '',
  },

  onLoad: function () {
    const that = this
    let card_info = wx.BaaS.storage.get('card_infor')
    console.log(card_info.card_id)
    if(card_info.card_id == "" || card_info.card_id == null){
      console.log("index:" + "未领取会员卡！")
      that.setData({
        isPlay1: 'none',
        isPlay2: '',
        card_id: '',
        scope: ''
      })
    }else{
      console.log("index:" + "已领取会员卡！")
      that.setData({
        isPlay1: '',
        isPlay2: 'none',
        card_id: card_info.card_id,
        scope: card_info.effective_point
      })
    }
  },

})