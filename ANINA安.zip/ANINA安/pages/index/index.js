//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    isPlay1: 'none',
    isPlay2: 'none',
    card_id: '',
    scope: '',
    checkAppJs: '',
  },

    // 再次显示
    onShow: function(){
      this.onLoad()
    },

  onLoad: function () {
    // let checkAppJs = wx.BaaS.storage.get('checkAppJs')
    const that = this
    let self_infor = wx.BaaS.storage.get('self_infor')
    console.log("检测：" + app.globalData.checkAppJs)
    if (app.globalData.checkAppJs){
      console.log('第一次回调', app.globalData.checkAppJs);
      that.setData({
        checkAppJs: app.globalData.checkAppJs,
      })
      if(that.data.checkAppJs == '' || that.data.checkAppJs == null){
        console.log("还没呢别急!")
      }else{
        console.log("好了！")
        let card_info = wx.BaaS.storage.get('card_infor')
        console.log(card_info.card_id)
        console.log(card_info.effective_point)
        if(card_info.card_id == "" || card_info.card_id == null){
          console.log("index:" + "未领取会员卡！")
          that.setData({
            isPlay1: 'none',
            isPlay2: '',
            card_id: '',
            scope: ''
          })
          wx.BaaS.storage.set('show_time', 1)
        }else{
          console.log("index:" + "已领取会员卡！")
          that.setData({
            isPlay1: '',
            isPlay2: 'none',
            card_id: card_info.card_id,
            scope: card_info.effective_point
          })
          wx.BaaS.storage.set('show_time', 1)
        }
      }
    }else{
      app.callback = () => {
        console.log('再次回调', app.globalData.checkAppJs);
        that.setData({
          checkAppJs: app.globalData.checkAppJs,
        })
        if(that.data.checkAppJs == '' || that.data.checkAppJs == null){
          console.log("还没呢别急!")
        }else{
          console.log("好了！")
          let card_info = wx.BaaS.storage.get('card_infor')
          console.log(card_info.card_id)
          console.log(card_info.effective_point)
          if(card_info.card_id == "" || card_info.card_id == null){
            console.log("index:" + "未领取会员卡！")
            that.setData({
              isPlay1: 'none',
              isPlay2: '',
              card_id: '',
              scope: ''
            })
            wx.BaaS.storage.set('show_time', 1)
          }else{
            console.log("index:" + "已领取会员卡！")
            that.setData({
              isPlay1: '',
              isPlay2: 'none',
              card_id: card_info.card_id,
              scope: card_info.effective_point
            })
            wx.BaaS.storage.set('show_time', 1)
          }
        }
      }
    }

    return
    if(that.data.checkAppJs == '' || that.data.checkAppJs == null){
      console.log("还没呢别急!")
    }
    if(that.data.checkAppJs != ''){
      console.log("有了！")
    }
    return
    if(self_infor.user_openid == '' || self_infor.user_openid == null){
      console.log("还没呢别急!")
    }else{
      let card_info = wx.BaaS.storage.get('card_infor')
      console.log(card_info.card_id)
      console.log(card_info.effective_point)
      if(card_info.card_id == "" || card_info.card_id == null){
        console.log("index:" + "未领取会员卡！")
        that.setData({
          isPlay1: 'none',
          isPlay2: '',
          card_id: '',
          scope: ''
        })
      }else{
        console.log("index:" + "已领取会员卡！")
        that.setData({
          isPlay1: '',
          isPlay2: 'none',
          card_id: card_info.card_id,
          scope: card_info.effective_point
        })
      }
    }
  },


})