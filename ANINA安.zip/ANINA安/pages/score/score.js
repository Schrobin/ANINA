//score.js
const app = getApp()
Page({
  data: {
    list:[
      '激活成功即赠送100积分',
      '每消费1.00元，赠送1积分',
      '每使用100积分，抵扣1.00元',
      '用卡可享受8折优惠',
      '微信会员满1000积分可兑换钥匙链一个',
      '微信会员满2000积分可兑换钱包一个'
    ],
    detail_list:[

    ],
    scope: '',
    box_height: '',
    box_display: '',
  },
  onLoad: function () {
   console.log('咔咔')
   let card_infor = wx.BaaS.storage.get('card_infor')
   let card_point_infor = wx.BaaS.storage.get('card_point_infor')
   this.setData({
    scope: card_infor.effective_point,
    detail_list: card_point_infor,
    box_height: 'auto'
   })
   console.log(this.data.scope)
   console.log(this.data.detail_list)   
  },
  
  control_hide: function(res){
    if(this.data.box_height == "auto"){
      this.setData({
        box_height: '0',
        box_display: 'none',
      })
    }else if(this.data.box_height == "0"){
      this.setData({
        box_height: 'auto',
        box_display: '',
      })
    }
    
  },
})
