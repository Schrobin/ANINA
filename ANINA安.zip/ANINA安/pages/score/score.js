//score.js
const app = getApp()
Page({
  data: {
    list:[
      '激活成功即赠送100积分',
      '每消费1.00元，赠送1积分',
      '每使用100积分，抵扣1.00元',
      '用卡可享受8折优惠',
      '微信会员满1000积分可兑换钥匙链一个',
      '微信会员满2000积分可兑换钱包一个'
    ],
    detail_list:[

    ],
    scope: '',
  },
  onLoad: function () {
   console.log('咔咔')
  },
})
