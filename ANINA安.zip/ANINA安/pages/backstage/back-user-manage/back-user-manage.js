//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    user_info: [],
    membership_card: [],
    users: [],
    telephone: '',
    user: {},
    scope_get: [],
    isShowUser: 'none'
  },

  // 加载
  onLoad: function () {
    this.searchUserInfo()
    // console.log("..")
  },

  // 用户表,会员卡查询
  searchUserInfo: function(){
    let that = this
    let res1 = []
    let res2 = []
    var Product = new wx.BaaS.TableObject('user_info')
    Product.orderBy('user_openid').find().then(res => {
      that.setData({
        user_info: res.data.objects
      })
      res1 = res.data.objects
      var Product = new wx.BaaS.TableObject('membership_card')
      Product.orderBy('user_openid').find().then(res=>{
        that.setData({
          membership_card: res.data.objects
        })
        res2 =  res.data.objects
        that.integratingData(res1, res2)
      })
    }, err => {
    })
  },

  // 用户数据整合
  integratingData: function(user_info, membership_card){
    var users = []
    for(let i = 0; i < user_info.length; i++){
      let user = [{
        username: user_info[i].username,
        card_id: user_info[i].card_id,
        birthday: user_info[i].birthday,
        gender: user_info[i].gender,
        user_regtime: user_info[i].user_regtime,
        effective_point: membership_card[i].effective_point,
        accumulation_point: membership_card[i].accumulation_point,
      }]
      users = users.concat(user)
    }
    console.log(users)
    this.setData({
      users: users
    })
  },

  // 获得输入的电话号
  getUserTelephone:function(e){
    this.setData({
      telephone: e.detail.value
    })
  },

  // 按卡号查询用户
  searchUser: function(){
    let telephone = this.data.telephone
    this.searchUserByCardID(telephone)
  },

  // 查询单个
  searchUserByCardID: function(tel){
    let that = this
    var user_full = {}
    // 用户信息
    let User = new wx.BaaS.TableObject('user_info')
    let user_ = new wx.BaaS.Query()
    user_.compare('telephone', '=',  tel)
    User.setQuery(user_).find().then(res => {
      // success
      // console.log(res.data.objects)
      if(res.data.objects == "" || res.data.objects == null){
        console.log("没有该用户")
        wx.showModal({
          title: '提示',
          content: '没有该会员！',
          showCancel: false,
          success (res) {

          }
        })
        return
      }else{
        // 会员卡
        var user_half = res.data.objects[0]
        let Card = new wx.BaaS.TableObject('membership_card')
        let card = new wx.BaaS.Query()
        card.compare('card_id', '=',  tel)
        Card.setQuery(card).find().then(res => {
          // success
          // console.log(res)
          if(res.data.objects == "" || res.data.objects == null){
            console.log("没有该用户")
            wx.showModal({
              title: '提示',
              content: '没有该会员！',
              showCancel: false,
              success (res) {
                
              }
            })
            return
          }else{
            user_full = {
              username: user_half.username,
              card_id: user_half.card_id,
              birthday: user_half.birthday,
              gender: user_half.gender,
              user_regtime: user_half.user_regtime,
              effective_point: res.data.objects[0].effective_point,
              accumulation_point: res.data.objects[0].accumulation_point,
            }
            // that.setData({
            //   user: user_full,
            //   scope_get: []
            // })
            // console.log(that.data.user)
            // accumulation_point: "100"
            // birthday: "1998-4-15"
            // card_id: "18535911335"
            // effective_point: "100"
            // gender: "男"
            // user_regtime: "2020-07-26 23:20"
            // username: "薛陈斌"

            // 积分记录
            let Score = new wx.BaaS.TableObject('score_get_info')
            let score = new wx.BaaS.Query()
            score.compare('card_id', '=',  tel)
            Score.setQuery(score).orderBy('-created_at').find().then(res => {
              // success
              // console.log(res)
              if(res.data.objects == "" || res.data.objects == null){
                console.log("没有该用户")
                return
              }else{
                // console.log(res.data.objects)
                that.setData({
                  user: user_full,
                  scope_get: res.data.objects,
                  isShowUser: ''
                })
                // console.log(that.data.scope_get)
              }
            }, err => {
              // err
            })
          }
        }, err => {
          // err
        })
      }
    }, err => {
      // err
    })
    return
  },


  // 删除用户
  deleteUser: function(){
    // console.log(this.data.user.card_id)
    let that = this
    wx.showModal({
      title: '提示',
      content: '确认注销该会员？',
      success (res) {
        if (res.confirm) {
          // 删除 tableName 为 'product' 的数据表中 recordID 为 59897882ff650c0477f00485 的数据项
          let MyTableObject = new wx.BaaS.TableObject('user_info')
          let query = new wx.BaaS.Query()
          // 设置查询条件（比较、字符串包含、组合等）
          query.compare('telephone', '=', that.data.user.card_id)
          MyTableObject.delete(query).then(res => {
            console.log(res)
            // 删除 tableName 为 'product' 的数据表中 recordID 为 59897882ff650c0477f00485 的数据项
            let MyTableObject1 = new wx.BaaS.TableObject('membership_card')
            let query1 = new wx.BaaS.Query()
            // 设置查询条件（比较、字符串包含、组合等）
            query1.compare('card_id', '=', that.data.user.card_id)
            MyTableObject1.delete(query1).then(res => {
              console.log(res)
              // 删除 tableName 为 'product' 的数据表中 recordID 为 59897882ff650c0477f00485 的数据项
              let MyTableObject2 = new wx.BaaS.TableObject('score_get_info')
              let query2 = new wx.BaaS.Query()
              // 设置查询条件（比较、字符串包含、组合等）
              query2.compare('card_id', '=', that.data.user.card_id)
              MyTableObject2.delete(query2).then(res => {
                console.log(res)
                wx.showModal({
                  title: '提示',
                  content: '删除成功！',
                  showCancel: false,
                  success (res) {
                    console.log('删除成功！')
                    that.setData({
                      isShowUser: 'none'
                    })
                    that.onLoad()
                  }
                })
              }, err => {
                console.log(err)
              })
            }, err => {
              console.log(err)
            })
          }, err => {
            console.log(err)
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
})