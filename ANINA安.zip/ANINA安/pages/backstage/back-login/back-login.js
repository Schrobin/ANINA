//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    username: '',
    password: ''
  },

  onLoad: function () {

  },

  // 获取用户名
  getUsername: function(e){
    this.setData({
      username: e.detail.value
    })
  },

  // 获取密码
  getPassword: function(e){
    this.setData({
      password: e.detail.value
    })
  },

  // 登录
  login: function(e){
    this.searchAdminUserInfo()
  },

  // 查询是否为管理员
  searchAdminUserInfo: function(){
    let that = this
    let admin_user_info = 103450
    let telephone = wx.BaaS.storage.get("self_infor").telephone
    let query_getPointInfor = new wx.BaaS.Query()
    let Product = new wx.BaaS.TableObject(admin_user_info)
    query_getPointInfor.compare('telephone', '=', telephone)
    Product.setQuery(query_getPointInfor).find().then(res => {
      if(res.statusCode == 200){
        if(res.data.objects.length == 0){
          wx.showModal({
            title: '提示',
            content: '非管理员，您没有权限！',
            showCancel: false,
            success (res) {
              return
            }
          })
        }else if(res.data.objects.length == 1){
          if(that.data.username == "ANINA_root_15035707871" && that.data.password == "15035707871"){
            console.log("登录成功！")
            wx.redirectTo({
              url: '../back-index/back-index',
            })
          }else{
            console.log("账号或密码错误！")
            return
          }
        }
      }else{
        console.log("状态码非200")
        return
      }
    }, err => {
      console.log("error!")
      return
    })
  }
})