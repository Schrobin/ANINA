//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    box_display: '',
    box_display1: 'none',
    box_height: '0',
    box_bottom: '20px'
  },

  onLoad: function () {
    
  },

  userManage: function(e){
    if(this.data.box_height == '0'){
      this.setData({
        box_display: 'none',
        box_display1: '',
        box_height: '50px',
        box_bottom: '0'
      })
    }else{
      this.setData({
        box_display: '',
        box_display1: 'none',
        box_height: '0',
        box_bottom: '20px'
      })
    }
  },

  toUserManage: function(){
    wx.navigateTo({
      url: '../back-user-manage/back-user-manage',
    })
  },

  toAdminManage: function(){
    wx.navigateTo({
      url: '../back-admin-manage/back-admin-manage',
    })
  },

  toAdminLogs: function(){
    wx.navigateTo({
      url: '../back-logs/back-logs',
    })
  },

  userManage: function(e){
    if(this.data.box_height == '0'){
      this.setData({
        box_display: 'none',
        box_display1: '',
        box_height: '50px',
        box_bottom: '0'
      })
    }else{
      this.setData({
        box_display: '',
        box_display1: 'none',
        box_height: '0',
        box_bottom: '20px'
      })
    }
  },


  toPointSearch: function(){
    wx.navigateTo({
      url: '../back-search-point/back-search-point',
    })
  }

})