//index.js
var util = require('../../../../utils/util')
Page({
  data: {
    user: {},
    scope_get: [],
    card_infor: {},
    scope: '',
    sub_scope: '',
    firstUpdate: '',
    resetUpdate: 'none',
    firstDelete: '',
    resetDelete: 'none',
  },

  onLoad: function () {

    console.log(wx.BaaS.storage.get('manage_user'))
    console.log(wx.BaaS.storage.get('manage_card'))
    console.log(wx.BaaS.storage.get('manage_scope_get'))
    // let card_infor = this.searchUserCard()

    // this.setData({
    //   user: wx.BaaS.storage.get('admin_user_manage'),
    //   scope_get: wx.BaaS.storage.get('admin_user_scope_get_manage'),
    //   card_infor: card_infor
    // })
    
  },

  // 查询用户会员卡
  searchUserCard: function(){
    var Product = new wx.BaaS.TableObject('membership_card')
    var query = new wx.BaaS.Query()
    query.compare('card_id', '=', wx.BaaS.storage.get('admin_user_manage').card_id)
    // 升序
    Product.setQuery(query).find().then(res => {
      // success
      return res.data.objects[0]
    }, err => {
      // err
    })
  },

  // 获取输入积分
  getPoint: function(e){
    this.setData({
      scope : e.detail.value
    })
  },

  getSubPoint: function(e){
    this.setData({
      sub_scope : e.detail.value
    })
  },

  // 更新用户消费积分
  updateUserPoint: function(){
    let that = this
    let scope = this.data.scope
    // console.log(scope)
    if(scope == "" || scope == null){
      console.log("请输入数据！")
      wx.showModal({
        title: '提示',
        content: '请输入数据！',
        showCancel: false,
        success (res) {
          
        }
      })
      return
    }else{
      // 向 tableName 为 'product' 的数据表插入一条记录
      let Product = new wx.BaaS.TableObject('score_get_info')
      let product = Product.create()

      // 设置方式一
      let apple = {
        card_id: that.data.user.card_id,
        username: that.data.user.username,
        user_openid: that.data.user.user_openid,
        obtain_method: '消费送积分',
        obtain_num: '+' + scope,
        created_time: util.timeToDate()
      }

      product.set(apple).save().then(res => {
        // success
        console.log(res)
        if(res.statusCode == 201 && res.errMsg == "request:ok"){
          console.log("修改成功")
          // return
          // 积分记录
          let Score = new wx.BaaS.TableObject('score_get_info')
          let score = new wx.BaaS.Query()
          score.compare('card_id', '=', that.data.user.card_id)
          Score.setQuery(score).orderBy('-created_at').find().then(res => {
            // success
            // console.log(res)
            if(res.data.objects == "" || res.data.objects == null){
              console.log("没有该用户")
              wx.showModal({
                title: '提示',
                content: '没有该会员！',
                showCancel: false,
                success (res) {

                }
              })
              return
            }else{
              // console.log(res.data.objects)
              that.setData({
                scope_get: res.data.objects,
                firstUpdate: '',
                resetUpdate: 'none'
              })
              // console.log(that.data.scope_get)
              wx.BaaS.storage.set('admin_user_scope_get_manage', res.data.objects)

              // 更新用户总积分
              that.updatePoint()
              
              that.onLoad();
              // return

            }
          }, err => {
            // err
          })
        }else{
          console.log("修改失败！")
        }
      }, err => {
        //err 为 HError 对象
      })
    }
    
  },

  // 更新增加积分
  updatePoint: function(){
    let that = this
    let scope_get = this.data.scope_get
    let total_point= 0
    
    for(let i = 0;i < scope_get.length;i++){
      let b = parseInt(scope_get[i].obtain_num.substring(1))
      total_point = total_point + b
      // console.log(total_point)
    }

    let consumption_point = '' + total_point - 100 + ''
    console.log(consumption_point)
    // return
    let membership = new wx.BaaS.TableObject('membership_card').getWithoutData(wx.BaaS.storage.get("admin_user_manage").id)
    membership.set({
      card_id: that.data.user.card_id,
      username: that.data.user.username,
      user_openid: that.data.user.user_openid,
      accumulation_point: '' + total_point + '',
      effective_point: '' + total_point + '',
      active_point: '100',
      consumption_point: consumption_point
    })
    membership.update().then(res => {
      // console.log(res)
      that.setData({
        firstUpdate: 'none',
        resetUpdate: ''
      })
      return
    })
  },

  // 减少积分
  deleteUserPoint: function(){
    let that = this
    this.deletePoint()
    // let sub_scope = this.data.sub_scope
    // // console.log(scope)
    // if(sub_scope == "" || sub_scope == null){
    //   console.log("请输入数据！")
    //   wx.showModal({
    //     title: '提示',
    //     content: '请输入数据！',
    //     showCancel: false,
    //     success (res) {
          
    //     }
    //   })
    //   return
    // }else if(!parseInt(sub_scope)%100 == 0){
    //   console.log("请输入100的倍数！")
    //   wx.showModal({
    //     title: '提示',
    //     content: '请输入100的倍数！',
    //     showCancel: false,
    //     success (res) {
          
    //     }
    //   })
    //   return
    // }else{
    //   // 向 tableName 为 'product' 的数据表插入一条记录
    //   let Product = new wx.BaaS.TableObject('score_get_info')
    //   let product = Product.create()

    //   // 设置方式一
    //   let apple = {
    //     card_id: that.data.user.card_id,
    //     username: that.data.user.username,
    //     user_openid: that.data.user.user_openid,
    //     obtain_method: '100积分抵扣1元',
    //     obtain_num: '-' + scope,
    //     created_time: util.timeToDate()
    //   }

    //   product.set(apple).save().then(res => {
    //     // success
    //     console.log(res)
    //     if(res.statusCode == 201 && res.errMsg == "request:ok"){
    //       console.log("修改成功")
    //       // return
    //       // 积分记录
    //       let Score = new wx.BaaS.TableObject('score_get_info')
    //       let score = new wx.BaaS.Query()
    //       score.compare('card_id', '=', that.data.user.card_id)
    //       Score.setQuery(score).orderBy('-created_at').find().then(res => {
    //         // success
    //         // console.log(res)
    //         if(res.data.objects == "" || res.data.objects == null){
    //           console.log("没有该用户")
    //           wx.showModal({
    //             title: '提示',
    //             content: '没有该会员！',
    //             showCancel: false,
    //             success (res) {

    //             }
    //           })
    //           return
    //         }else{
    //           // console.log(res.data.objects)
    //           that.setData({
    //             scope_get: res.data.objects,
    //             firstDelete: '',
    //             resetDelete: 'none'
    //           })
    //           // console.log(that.data.scope_get)
    //           wx.BaaS.storage.set('admin_user_scope_get_manage', res.data.objects)
    //           // 更新用户总积分
    //           that.deletePoint()
    //           that.onLoad();
    //           // return
    //         }
    //       }, err => {
    //         // err
    //       })
    //     }else{
    //       console.log("修改失败！")
    //     }
    //   }, err => {
    //     //err 为 HError 对象
    //   })
    // }
  },

  // 更新减少积分
  deletePoint: function(){
    let that = this
    // let membership = new wx.BaaS.TableObject('membership_card').getWithoutData(wx.BaaS.storage.get("admin_user_manage").id)
    // membership.set({
    //   card_id: that.data.user.card_id,
    //   username: that.data.user.username,
    //   user_openid: that.data.user.user_openid,
    //   accumulation_point: '' + total_point + '',
    //   effective_point: '' + total_point + '',
    //   active_point: '100',
    //   consumption_point: consumption_point
    // })
    // membership.update().then(res => {
    //   // console.log(res)
      that.setData({
        firstDelete: 'none',
        resetDelete: ''
      })
    //   return
    // })
    console.log("更新减少积分：" + "deletePoint")
  },

  // 再次修改
  resetUpdate: function(){
    this.setData({
      firstUpdate: '',
      resetUpdate: 'none'
    })
  },

  // 再次减少
  resetDelete:function(){
    this.setData({
      firstDelete: '',
      resetDelete: 'none'
    })
  },

  // 返回
  goBack: function(){
    wx.redirectTo({
      url: '../back-search-point',
    })
  },

})
