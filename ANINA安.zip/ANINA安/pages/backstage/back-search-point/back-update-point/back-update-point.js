//index.js
var util = require('../../../../utils/util')
Page({
  data: {
    manage_user: {},
    manage_scope_get: [],
    manage_card: {},
    scope: '',
    sub_scope: '',
    firstUpdate: '',
    resetUpdate: 'none',
    firstDelete: '',
    resetDelete: 'none',
  },

  onLoad: function () {

    let manage_user = wx.BaaS.storage.get('manage_user')
    let manage_card = wx.BaaS.storage.get('manage_card')
    let manage_scope_get = wx.BaaS.storage.get('manage_scope_get')

    // console.log(manage_user)
    // console.log(manage_card)
    // console.log(manage_scope_get)

    // return
    // console.log('有效积分' + manage_card.effective_point)
    // console.log('累计积分' + manage_card.accumulation_point)

    if(manage_user == {}){
      wx.navigateBack({
        delta: 1,
      })
    }else{
      this.setData({
        manage_user,
        manage_card,
        manage_scope_get
      })
    }

  },



  // 获取输入积分
  getPoint: function(e){
    this.setData({
      scope : e.detail.value
    })
  },

  // 获取输入积分
  getSubPoint: function(e){
    this.setData({
      sub_scope : e.detail.value
    })
  },

  // 更新用户消费积分
  updateUserPoint: function(){
    let that = this
    let scope = this.data.scope
    // this.updatePoint()
    // return
    // console.log(scope)
    if(scope == "" || scope == null){
      console.log("请输入数据！")
      wx.showModal({
        title: '提示',
        content: '请输入数据！',
        showCancel: false,
        success (res) {
          
        }
      })
      return
    }else{
      // 向 tableName 为 'product' 的数据表插入一条记录
      let Product = new wx.BaaS.TableObject('score_get_info')
      let product = Product.create()

      // 设置方式一
      let apple = {
        card_id: that.data.manage_user.card_id,
        username: that.data.manage_user.username,
        user_openid: that.data.manage_user.user_openid,
        obtain_method: '消费送积分',
        obtain_num: scope,
        plus_minus: '+',
        created_time: util.timeToDate()
      }

      product.set(apple).save().then(res => {
        // success
        console.log(res)
        if(res.statusCode == 201 && res.errMsg == "request:ok"){
          console.log("修改成功")
          // return
          // 积分记录
          let Score = new wx.BaaS.TableObject('score_get_info')
          let score = new wx.BaaS.Query()
          score.compare('card_id', '=', that.data.manage_user.card_id)
          Score.setQuery(score).orderBy('-created_at').find().then(res => {
            // success
            // console.log(res)
            if(res.data.objects == "" || res.data.objects == null){
              console.log("没有该用户")
              wx.showModal({
                title: '提示',
                content: '没有该会员！',
                showCancel: false,
                success (res) {

                }
              })
              return
            }else{
              // console.log(res.data.objects)
              that.setData({
                // manage_scope_get: res.data.objects,
                firstUpdate: '',
                resetUpdate: 'none'
              })
              // console.log(that.data.manage_scope_get)
              wx.BaaS.storage.set('manage_scope_get', res.data.objects)
              
              wx.showModal({
                title: '提示',
                content: '增加成功！',
                showCancel: false,
                success (res) {
                  if(res.confirm){
                    // 更新用户总积分
                    that.calculatePoint('+')
                    that.onLoad();
                  }
                }
              })

            }
          }, err => {
            // err
          })
        }else{
          console.log("修改失败！")
        }
      }, err => {
        //err 为 HError 对象
      })
    }
    
  },

  // 减少积分
  deleteUserPoint: function(){
    let that = this
    let sub_scope = this.data.sub_scope

    // return
    // this.updatePoint()
    // return
    // console.log(scope)
    if(sub_scope == "" || sub_scope == null){
      console.log("请输入数据！")
      wx.showModal({
        title: '提示',
        content: '请输入数据！',
        showCancel: false,
        success (res) {
          
        }
      })
      return
    }else if(parseInt(sub_scope)%100 != 0){
      wx.showModal({
        title: '提示',
        content: '请输入100的倍数！',
        showCancel: false,
        success (res) {
          
        }
      })
      return
    }else if(parseInt(sub_scope) > that.data.manage_card.effective_point){
      wx.showModal({
        title: '提示',
        content: '不能超过用户所拥有积分！',
        showCancel: false,
        success (res) {
          
        }
      })
      return
    }else{
      // 向 tableName 为 'product' 的数据表插入一条记录
      let Product = new wx.BaaS.TableObject('score_get_info')
      let product = Product.create()

      // 设置方式一
      let apple = {
        card_id: that.data.manage_user.card_id,
        username: that.data.manage_user.username,
        user_openid: that.data.manage_user.user_openid,
        obtain_method: '积分抵消现金',
        obtain_num: sub_scope,
        plus_minus: '-',
        created_time: util.timeToDate()
      }

      product.set(apple).save().then(res => {
        // success
        console.log(res)
        if(res.statusCode == 201 && res.errMsg == "request:ok"){
          console.log("修改成功")
          // return
          // 积分记录
          let Score = new wx.BaaS.TableObject('score_get_info')
          let score = new wx.BaaS.Query()
          score.compare('card_id', '=', that.data.manage_user.card_id)
          Score.setQuery(score).orderBy('-created_at').find().then(res => {
            // success
            // console.log(res)
            if(res.data.objects == "" || res.data.objects == null){
              console.log("没有该用户")
              wx.showModal({
                title: '提示',
                content: '没有该会员！',
                showCancel: false,
                success (res) {

                }
              })
              return
            }else{
              // console.log(res.data.objects)
              that.setData({
                // manage_scope_get: res.data.objects,
                firstDelete: '',
                resetDelete: 'none'
              })
              // console.log(that.data.manage_scope_get)
              wx.BaaS.storage.set('manage_scope_get', res.data.objects)

              wx.showModal({
                title: '提示',
                content: '减少成功！',
                showCancel: false,
                success (res) {
                  if(res.confirm){
                    // 更新用户总积分
                    that.calculatePoint('-')
                    that.onLoad();
                  }
                  // return
                }
              })

            }
          }, err => {
            // err
          })
        }else{
          console.log("修改失败！")
        }
      }, err => {
        //err 为 HError 对象
      })
    }
  },
  
  // 更新增加积分
  calculatePoint: function(operator){
    let that = this
    let scope = parseInt(this.data.scope)
    let sub_scope = parseInt(this.data.sub_scope)
    let manage_scope_get = parseInt(this.data.manage_scope_get)
    let manage_card = this.data.manage_card
    let accumulation_point = parseInt(manage_card.accumulation_point)
    let effective_point = parseInt(manage_card.effective_point)
    // console.log(this.data.manage_card)
    // console.log(this.data.manage_scope_get)

    // return
    // console.log(manage_card.id)

    if(operator == '+'){
      console.log("加法")
      // console.log(accumulation_point + 1)
      effective_point = effective_point + scope
      accumulation_point = accumulation_point + scope

    }
    if(operator == '-'){
      console.log("减法")
      // console.log(accumulation_point - 1)
      // console.log(effective_point)
      // console.log(sub_scope)
      effective_point = effective_point - sub_scope
      // console.log(effective_point)
    }
    // return

    let consumption_point = '' + accumulation_point - 100 + ''
    // console.log(consumption_point)
    // return
    let membership = new wx.BaaS.TableObject('membership_card').getWithoutData(manage_card.id)
    membership.set({
      card_id: that.data.manage_user.card_id,
      username: that.data.manage_user.username,
      user_openid: that.data.manage_user.user_openid,
      accumulation_point: '' + accumulation_point + '',
      effective_point: '' + effective_point + '',
      active_point: '100',
      consumption_point: consumption_point
    })
    membership.update().then(res => {
      // console.log(res.data)
      wx.BaaS.storage.set('manage_card', res.data)
      if(operator == '+'){
        that.setData({
          firstUpdate: 'none',
          resetUpdate: ''
        })
      }
      if(operator == '-'){
        that.setData({
          firstDelete: 'none',
          resetDelete: ''
        })
      }

      that.onLoad()
      return
    })
  },

  // 再次修改
  resetUpdate: function(){
    this.setData({
      firstUpdate: '',
      resetUpdate: 'none'
    })
  },

  // 再次减少
  resetDelete:function(){
    this.setData({
      firstDelete: '',
      resetDelete: 'none'
    })
  },

  // 返回
  goBack: function(){
    wx.navigateBack({
      delta: 1,
    })
  },

  // // 查询用户会员卡
  // searchUserCard: function(){
  //   var Product = new wx.BaaS.TableObject('membership_card')
  //   var query = new wx.BaaS.Query()
  //   query.compare('card_id', '=', wx.BaaS.storage.get('admin_user_manage').card_id)
  //   // 升序
  //   Product.setQuery(query).find().then(res => {
  //     // success
  //     return res.data.objects[0]
  //   }, err => {
  //     // err
  //   })
  // },
})
