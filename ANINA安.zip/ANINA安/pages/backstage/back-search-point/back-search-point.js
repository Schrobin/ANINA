//index.js
Page({
  data: {
    isShowUser: 'none',
  },

  onLoad: function () {
    this.setData({
      manage_user: wx.BaaS.storage.get('manage_user'),
      manage_card: wx.BaaS.storage.get('manage_card'),
      manage_scope_get: wx.BaaS.storage.get('manage_scope_get'),
    })
    // console.log(this.data.manage_user)
    // console.log(this.data.manage_card)
    // console.log(this.data.manage_scope_get)
  },

  // 扫描二维码
  scanCode: function(){
    let that = this
    // 只允许从相机扫码
    wx.scanCode({
      onlyFromCamera: true,
      success (res) {
        console.log(res.result)
        // wx.BaaS.storage.set('user_telephone', res.result)
        that.searchUserByCardID(res.result)
      }
    })
  },

  // 查询单个
  searchUserByCardID: function(tel){
    let that = this
    var manage_user = {}
    var manage_card = {}
    var manage_scope_get = []
    // 用户信息
    let User = new wx.BaaS.TableObject('user_info')
    let user_ = new wx.BaaS.Query()
    user_.compare('telephone', '=', tel)
    User.setQuery(user_).find().then(res => {
      // success
      // console.log(res.data.objects)
      if(res.data.objects == "" || res.data.objects == null){
        console.log("没有该用户")
        wx.showModal({
          title: '提示',
          content: '没有该会员！',
          showCancel: false,
          success (res) {

          }
        })
        return
      }else{
        // 会员卡
        manage_user = res.data.objects[0]
        let Card = new wx.BaaS.TableObject('membership_card')
        let card = new wx.BaaS.Query()
        card.compare('card_id', '=', tel)
        Card.setQuery(card).find().then(res => {
          // success
          // console.log(res)
          if(res.data.objects == "" || res.data.objects == null){
            console.log("没有该用户")
            return
          }else{
            console.log(res.data.objects)
            // 积分记录
            manage_card = res.data.objects[0]
            let Score = new wx.BaaS.TableObject('score_get_info')
            let score = new wx.BaaS.Query()
            score.compare('card_id', '=', tel)
            Score.setQuery(score).orderBy('-created_at').find().then(res => {
              // success
              // console.log(res)
              if(res.data.objects == "" || res.data.objects == null){
                console.log("没有该用户")
                return
              }else{
                // console.log(res.data.objects)
                manage_scope_get = res.data.objects
                that.setData({
                  manage_user,
                  manage_card,
                  manage_scope_get,
                  isShowUser: ''
                })
                // console.log(that.data.scope_get)
                wx.BaaS.storage.set('manage_user', that.data.manage_user)
                wx.BaaS.storage.set('manage_card', that.data.manage_card)
                wx.BaaS.storage.set('manage_scope_get', that.data.manage_scope_get)
              }
            }, err => {
              // err
            })
          }
        }, err => {
          // err
        })
      }
    }, err => {
      // err
    })
    return
  },

  // 去更新积分页面
  toUpdatePoint: function(){
    wx.navigateTo({
      url: './back-update-point/back-update-point',
    })
  },

  // 
  onShow: function(){
    this.onLoad()
  },
})