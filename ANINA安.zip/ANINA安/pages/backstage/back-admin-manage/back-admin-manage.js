//index.js
Page({
  data: {
    admins: [],
    telephone: '',
    username: '',
    isShowUser: 'none',
    admin: {}
  },

  onLoad: function () {
    this.setData({
      admin_name: '',
      admin_telephone: ''
    })
    this.getAdminInfor()
  },

  // 查询所有admin
  getAdminInfor: function(){
    // admin_user_info 
    // 积分记录
    let that = this
    var Product = new wx.BaaS.TableObject('admin_user_info')
    Product.orderBy('user_openid').find().then(res => {
      that.setData({
        admins: res.data.objects
      })
    }, err => {
    })
  },

  // 获取输入的姓名
  getAdminName: function(e){
    this.setData({
      username: e.detail.value
    })
  },

  // 获取输入的手机号
  getAdminTelephone: function(e){
    this.setData({
      telephone: e.detail.value
    })
  },

  // 通过电话号查询单个管理员
  searchAdminByTel: function(){
    let that = this
    let Admin = new wx.BaaS.TableObject('admin_user_info')
    let admin = new wx.BaaS.Query()
    admin.compare('telephone', '=',  this.data.telephone)
    Admin.setQuery(admin).find().then(res => {
      // success
      // console.log(res)
      if(res.data.objects == "" || res.data.objects == null){
        console.log("没有该用户")
        wx.showModal({
          title: '提示',
          content: '没有该管理员！',
          showCancel: false,
          success (res) {
            return
          }
        })
        return
      }else{
        console.log(res.data.objects[0])
        let adm = {
          username: res.data.objects[0].username,
          telephone: res.data.objects[0].telephone
        }
        that.setData({
          admin: adm,
          isShowUser: ''
        })
        // console.log(that.data.scope_get)
      }
    }, err => {
      // err
    })
  },

  // 通过姓名查询单个管理员
  searchAdminByName: function(){
    let that = this
    let Admin = new wx.BaaS.TableObject('admin_user_info')
    let admin = new wx.BaaS.Query()
    admin.compare('username', '=',  this.data.username)
    Admin.setQuery(admin).find().then(res => {
      // success
      // console.log(res)
      if(res.data.objects == "" || res.data.objects == null){
        console.log("没有该用户")
        wx.showModal({
          title: '提示',
          content: '没有该管理员！',
          showCancel: false,
          success (res) {
            return
          }
        })
        return
      }else{
        // console.log(res.data.objects)
        let adm = {
          username: res.data.objects[0].username,
          telephone: res.data.objects[0].telephone
        }
        that.setData({
          admin: adm,
          isShowUser: ''
        })
        // console.log(that.data.scope_get)
      }
    }, err => {
      // err
    })
  },

  getName: function(e){
    this.setData({
      admin_name: e.detail.value
    })
  },

  getTelephone: function(e){
    this.setData({
      admin_telephone: e.detail.value
    })
  },

  addAdmin: function(){
    let that = this
    console.log(this.data.admin_name)
    console.log(this.data.admin_telephone)
    var name_reg = /^[\u4E00-\u9FA5]{1,6}$/ 
    var telephone_reg = /^0{0,1}(1[0-9][0-9]|15[7-9]|153|156|18[7-9])[0-9]{8}$/
    if(that.data.admin_name == '' || that.data.admin_name == null){
      that.showToast('姓名!')
      return
    }
    if(!name_reg.test(that.data.admin_name)){
      that.showToast('正确姓名格式!')
      return
    }
    if(that.data.admin_telephone == '' || that.data.admin_telephone == null){
      that.showToast('手机号!')
      return
    }
    if(!telephone_reg.test(that.data.admin_telephone)){
      that.showToast('正确手机号格式!')
      return
    }
    
    let Product = new wx.BaaS.TableObject('admin_user_info')
    let product = Product.create()

    // 设置方式一
    let apple = {
      username: this.data.admin_name,
      telephone: this.data.admin_telephone
    }

    product.set(apple).save().then(res => {
      // success
      console.log(res)
      wx.showModal({
        title: '提示',
        content: '添加成功',
        showCancel: false,
        success (res) {
          that.onLoad()
        }
      })
    }, err => {
      //err 为 HError 对象
    })
  },

  // 提示
  showToast: function(title){
    wx.showModal({
      title: '提示',
      content: '请输入' + title,
      showCancel: false,
      success (res) {

      }
    })
  },

})