//index.js
Page({
  data: {
    admins: [],
    telephone: '',
    username: '',
    isShowUser: 'none',
    admin: {}
  },

  onLoad: function () {
    this.getAdminInfor()
  },

  // 查询所有admin
  getAdminInfor: function(){
    // admin_user_info 
    // 积分记录
    let that = this
    var Product = new wx.BaaS.TableObject('admin_user_info')
    Product.orderBy('user_openid').find().then(res => {
      that.setData({
        admins: res.data.objects
      })
    }, err => {
    })
  },

  // 获取输入的姓名
  getAdminName: function(e){
    this.setData({
      username: e.detail.value
    })
  },

  // 获取输入的手机号
  getAdminTelephone: function(e){
    this.setData({
      telephone: e.detail.value
    })
  },

  // 通过电话号查询单个管理员
  searchAdminByTel: function(){
    let that = this
    let Admin = new wx.BaaS.TableObject('admin_user_info')
    let admin = new wx.BaaS.Query()
    admin.compare('telephone', '=',  this.data.telephone)
    Admin.setQuery(admin).find().then(res => {
      // success
      // console.log(res)
      if(res.data.objects == "" || res.data.objects == null){
        console.log("没有该用户")
        wx.showModal({
          title: '提示',
          content: '没有该管理员！',
          showCancel: false,
          success (res) {
            return
          }
        })
        return
      }else{
        console.log(res.data.objects[0])
        let adm = {
          username: res.data.objects[0].username,
          telephone: res.data.objects[0].telephone
        }
        that.setData({
          admin: adm,
          isShowUser: ''
        })
        // console.log(that.data.scope_get)
      }
    }, err => {
      // err
    })
  },

  // 通过姓名查询单个管理员
  searchAdminByName: function(){
    let that = this
    let Admin = new wx.BaaS.TableObject('admin_user_info')
    let admin = new wx.BaaS.Query()
    admin.compare('username', '=',  this.data.username)
    Admin.setQuery(admin).find().then(res => {
      // success
      // console.log(res)
      if(res.data.objects == "" || res.data.objects == null){
        console.log("没有该用户")
        wx.showModal({
          title: '提示',
          content: '没有该管理员！',
          showCancel: false,
          success (res) {
            return
          }
        })
        return
      }else{
        // console.log(res.data.objects)
        let adm = {
          username: res.data.objects[0].username,
          telephone: res.data.objects[0].telephone
        }
        that.setData({
          admin: adm,
          isShowUser: ''
        })
        // console.log(that.data.scope_get)
      }
    }, err => {
      // err
    })
  }
})