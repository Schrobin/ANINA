var util=require('../../utils/util')
Page({
  data: {
    list: [{
      title: '姓名',
      text: ''
    }, {
      title: '手机',
      text: ''
    }, {
      title: '性别',
      text: ''
    }, {
      title: '生日',
      text: ''
    }],
    userInfo:{},
    username: '',
    telephone: '',
    gender: '男',
    birthday: '',
    isScope: '',
    isMember: 'none',
    checked1: 'checked',
    checked0: '',
    year: '',
    month: '',
    day: ''
  },
  // 数据加载
  onLoad: function () {
    const that = this
    let self_info = wx.BaaS.storage.get('self_infor')
    if(wx.BaaS.storage.get('card_infor').card_id == null || wx.BaaS.storage.get('card_infor').card_id == ""){
      console.log("用户未领取会员卡")
      that.setData({
        isMember: 'none',
        isScope: '',
      })
    }else{
      console.log("用户已领取会员卡")
      that.setData({
        isMember: '',
        isScope: 'none',
        username: self_info.username,
        telephone: self_info.telephone,
        gender: self_info.gender,
        birthday: self_info.birthday
      })
    }
  },

  // 创建用户
  getUserinfo: function(res){
    const that = this
    var currentTime = util.formatTime(new Date())
    that.setData({
      user_regtime: currentTime
    })
    if(that.data.username == null || that.data.username == ""){
      that.showtoast("姓名")
      return
    }else{
      var name_reg = /^[\u4E00-\u9FA5]{1,6}$/    /*长度修改后面的数值即可*/
      if(!name_reg.test(that.data.username)){
        that.showtoast2("姓名格式")
        return
     }
    }
    if(that.data.telephone == null || that.data.telephone == ""){
      that.showtoast("手机号")
      return
    }else{
      var telephone_reg = /^0{0,1}(1[0-9][0-9]|15[7-9]|153|156|18[7-9])[0-9]{8}$/
      if(!telephone_reg.test(that.data.telephone)){
        that.showtoast2("手机号格式")
        return
     }
    }
    if(that.data.year == null || that.data.year == ""){
      that.showtoast("完整生日信息")
      return
    }
    if(that.data.month == null || that.data.month == ""){
      that.showtoast("完整生日信息")
      return
    }
    if(that.data.day == null || that.data.day == ""){
      that.showtoast("完整生日信息")
      return
    }
    that.setData({
      birthday : that.data.year + '-' + that.data.month + '-' + that.data.day
    })
    var birthday_reg =  /^(19|20)\d{2}-(1[0-2]|0?[1-9])-(0?[1-9]|[1-2][0-9]|3[0-1])$/
    if(!birthday_reg.test(that.data.birthday)){
      that.showtoast2("出生日期")
        return
    }
    // 用户信息
    console.log('my-info.js:用户信息' + wx.BaaS.storage.get("openid"))
    let user_info = {
      username: that.data.username,
      telephone: that.data.telephone,
      gender: that.data.gender,
      birthday: that.data.birthday,
      user_openid: wx.BaaS.storage.get("openid"),
      user_regtime: that.data.user_regtime,
      card_id: that.data.telephone,
    }
    // 会员卡信息
    let membership_card = {
      card_id: that.data.telephone,
      username: that.data.username,
      user_openid: wx.BaaS.storage.get("openid"),
      accumulation_point: '100',
      effective_point: '100',
      active_point: '100',
      consumption_point: '0'
    }
    that.addUser(user_info, membership_card)
    // 为用户创建会员卡
    // 2020年7月25日 23：25到此
    // console.log(wx.BaaS.storage.get("add_success"))
    // console.log(wx.BaaS.storage.get("card_success"))
  },

  addUser:function(res1, res2){
    // 更新用户
    const that = this
    let user = new wx.BaaS.TableObject('user_info').getWithoutData(wx.BaaS.storage.get("self_infor").id)
    user.set({
      username: res1.username,
      telephone: res1.telephone,
      gender: res1.gender,
      birthday: res1.birthday,
      user_openid: wx.BaaS.storage.get("openid"),
      user_regtime: res1.user_regtime,
      card_id: res1.telephone,
    })
    user.update().then(res => {
      // success
      wx.BaaS.storage.set('self_infor', res1)
      // 为用户开通会员卡
      let Card = new wx.BaaS.TableObject('membership_card')
      let card = Card.create()
      card.set(res2).save().then(res => {
        wx.BaaS.storage.set('card_infor', res2)
        wx.showModal({
          title: '成功',
          content: '领取成功',
          showCancel: false,
          success (res) {
            that.awardPoints()
            if (res.confirm) {
              wx.redirectTo({
                url: '../index/index',
              })
            }
          }
        })
      }, err => {
        //err 为 HError 对象
      })
    }, err => {
      // err
    })
    
  },

  // 激活送积分
  awardPoints:function(){
    let user_openid = wx.BaaS.storage.get("self_infor").user_openid
    let card_id = wx.BaaS.storage.get("self_infor").card_id
    let username = wx.BaaS.storage.get("self_infor").username
    let time = util.timeToDate()
    // console.log(time)
    let datas = [{
      card_id,
      username,
      user_openid,
      obtain_method: '激活送积分',
      obtain_num: '100',
      plus_minus: '+',
      created_time: time
    }]

    let Award = new wx.BaaS.TableObject('score_get_info')
    let award = Award.create()
    award.set(datas[0]).save().then(res => {
      console.log(res.data)
      wx.BaaS.storage.set('card_point_infor', datas)
    })

  },

  // 获取姓名
  saveName:function(e){
    this.setData({
      username : e.detail.value
    })
  },
  // 获取手机号
  saveTel:function(e){
    this.setData({
      telephone : e.detail.value
    })
  },
  // 获取性别
  radioChange:function(e){
    console.log(e.detail.value)
    this.setData({
      gender : e.detail.value
    })
  },
  // 获取年
  saveYear:function(e){
    this.setData({
      year : e.detail.value
    })
  },
  // 获取月
  saveMonth:function(e){
    this.setData({
      month : e.detail.value
    })
  },
  // 获取日
  saveDay:function(e){
    this.setData({
      day : e.detail.value
    })
  },

  // 表单不能为空
  showtoast:function(title){
    wx.showModal({
      title: '信息不完善',
      content: '请输入' + title,
      success (res) {
        if (res.confirm) {
          console.log('用户点击确定')
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },

  // 表单验证
  showtoast2:function(title){
    wx.showModal({
      title: '信息不正确',
      content: '请输入正确' + title,
      success (res) {}
    })
  },

  goBackIndex:function(){
    wx.redirectTo({
      url: '../index/index',
    })
  },

  navToBackstage:function(){
    this.searchAdminUserInfo()
  },

  // 查询是否为管理员
  searchAdminUserInfo: function(){
    let that = this
    let admin_user_info = 103450
    let telephone = wx.BaaS.storage.get("self_infor").telephone
    let query_getPointInfor = new wx.BaaS.Query()
    let Product = new wx.BaaS.TableObject(admin_user_info)
    query_getPointInfor.compare('telephone', '=', telephone)
    Product.setQuery(query_getPointInfor).find().then(res => {
      if(res.statusCode == 200){
        if(res.data.objects.length == 0){
          // 不是管理员
          return
        }else if(res.data.objects.length == 1){
          // 管理员
          wx.redirectTo({
            url: '../backstage/back-index/back-index',
          })
          // if(that.data.username == "ANINA_root_15035707871" && that.data.password == "15035707871"){
          //   console.log("登录成功！")
          //   wx.redirectTo({
          //     url: '../back-index/back-index',
          //   })
          // }else{
          //   console.log("账号或密码错误！")
          //   return
          // }
        }
      }else{
        console.log("状态码非200")
        return
      }
    }, err => {
      console.log("error!")
      return
    })
  }
})