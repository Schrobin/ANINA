//app.js
App({
  data: {
    //知晓云数据库的ID,调用示例: app.data.tableID.user_infor
    tableID: {
      user_info: 103327, //用户信息
      card_detail: 103326, //会员卡详情表
      membership_card: 103325, //会员卡积分表
      score_get_info: 103378, //积分获取表
    },
    userInfor: {}
  },

    /**
   * @callback
   * @desc 知晓云添加函数 
   * @summary 添加成功后会将该条记录返回在res.data中
   * @param tableID number 数据表ID
   * @param setMyRecord   wx.BaaS.creat 添加对象
   * @param rescb function 回调函数
   * @param errcb function 发生错误回调函数
   * @thorw 401 当请求组建错误时会在控制带发出警告，检查set中属性名是否与数据控中字段相同
   */
  addDataToMinapp: function(tableID, setMyRecord = () => {}, rescb = () => {}, errcb = () => {}) {
    //tableID 实例化一个TableObject对象
    let MyTableObject = new wx.BaaS.TableObject(tableID)
    //本地创建一条空记录
    let MyRecord = MyTableObject.create()
    //为上面创建的空记录赋值
    setMyRecord(MyRecord)
    //数据保存至云数据库
    MyRecord.save().then(res => {
      rescb(res)
    }, err => {
      errcb()
    })
  },

  /**
   * @callback
   * @desc 知晓云查询函数 
   * @param tableID number 数据表ID
   * @param query   wx.BaaS.Query 查询条件对象
   * @param callback function 回调函数
   * @param orderby String 查询的排序规则，详见知晓云排序查询
   * @returns res 查询到的结果
   * @throw "error"
   */
  searchDataInMinapp: function (tableID, query, callback = () => {}, orderby = '') {
    let Product = new wx.BaaS.TableObject(tableID)
    Product.setQuery(query).orderBy(orderby).find().then(res => {
      callback(res)
      return res
    }, err => {
      return "error"
    })
  },

    /**
   * @ignore 请勿随意调用该函数
   * @desc 将用户基本个人信息写入缓存，配合initialGetUserInfor()函数使用,
   */
  writeUserInforToStorage: function (datas) {
    const that = this
    // 将读取到的用户信息存入缓存
    let self_infor = {}
    let card_infor = {}
    let card_point_infor = []
    self_infor = {
      id: datas.id,
      card_id: datas.card_id || "",
      username: datas.username || "",
      telephone: datas.telephone || "",
      gender: datas.gender || "",
      birthday: datas.birthday || "",
      user_openid: datas.user_openid,
      user_regtime: datas.user_regtime
    }
    wx.BaaS.storage.set('self_infor', self_infor)
    if(datas.card_id == "" || datas.card_id == null){
      console.log('app.js:' + '未领取会员卡!')
      card_infor = {
        card_id: '',
        username: '',
        user_openid: datas.user_openid,
        accumulation_point: '0',
        effective_point: '0',
        active_point: '0',
        consumption_point: '0',
      }
      wx.BaaS.storage.set('card_infor', card_infor)
      card_point_infor = [{
        card_id: '',
        username: '',
        user_openid: datas.user_openid,
        obtain_method: '',
        obtain_num: '',
        created_time: ''
      }]
      wx.BaaS.storage.set('card_point_infor', card_point_infor)
    }else{
      console.log('app.js:' + '已领取会员卡!')
      // 将读取到的用户会员卡信息存入缓存
      let query_getCardInfor = new wx.BaaS.Query()
      console.log(datas.user_openid)
      query_getCardInfor.compare('user_openid', '=', datas.user_openid)
      this.searchDataInMinapp(this.data.tableID.membership_card, query_getCardInfor, (result) => {
        console.log(result)
        if (result.data.objects.length == 1) {
          let card_infor = result.data.objects[0]
          card_infor = {
            card_id: card_infor.card_id || "",
            username: card_infor.username || "",
            user_openid: datas.user_openid,
            accumulation_point: card_infor.accumulation_point,
            effective_point: card_infor.effective_point,
            active_point: card_infor.active_point,
            consumption_point: card_infor.consumption_point
          }
          wx.BaaS.storage.set('card_infor', card_infor)
        }else if(result.data.objects.length == 0){
          console.log("没有查到！")
          return
        }else{
          
        }
      })
      // 将读取到的用户积分获取存入缓存
      let query_getPointInfor = new wx.BaaS.Query()
      query_getPointInfor.compare('user_openid', '=', datas.user_openid)
      this.searchDataInMinapp(this.data.tableID.score_get_info, query_getPointInfor, (result) => {
        if(result.data.objects.length == 0){
          card_point_infor = [{
            card_id: '',
            username: '',
            user_openid: datas.user_openid,
            obtain_method: '',
            obtain_num: '',
            created_time: ''
          }]
          wx.BaaS.storage.set('card_point_infor', card_point_infor)
        }else{
          let datas = result.data.objects
          wx.BaaS.storage.set('card_point_infor', datas)
        }
      })
    }
  },

  /**
   * @desc 初始化个人信息，将个人信息存储在缓存中
   * @summary 该函数在onLaunch()函数调用，每次启动小程序时，都会获取到个人信息并且更新数据，避免频繁的调用数据库请求的方法。同时在每次对个人信息进行修改后，都要调用该方法对本地缓存及显示的信息进行更新
   */
  initialGetUserInfor: function () {
    const that = this
    //判断缓存中是否存在用户的openid,如果没有就重新进行登录操作获取openid信息
    if (wx.BaaS.storage.get("openid") == '' || wx.BaaS.storage.get("openid") == null) {
      // wx.BaaS.login()
      wx.BaaS.login(false).then(res => {
        // 登录成功
        console.log("重新登录成功")
        that.onLaunch()
      }, res => {
        // 登录失败
        console.log("重新登录失败")
      })
    } else {
      //在缓存中读取用户的openid
      const openid = wx.BaaS.storage.get("openid")
      // console.log(openid)
      let query_getUserInfor = new wx.BaaS.Query()
      query_getUserInfor.compare('user_openid', '=', openid)

      //在数据库中对用户信息进行查询
      this.searchDataInMinapp(this.data.tableID.user_info, query_getUserInfor, (result) => {
        //对用户的openid在数据库中的查询结果为1，说明用户已经注册过
        // console.log(result)
        if (result.data.objects.length == 1) {
          //获取用户的信息
          let datas = result.data.objects[0]
          //将信息存储在self_infor对象中，然后写入缓存
          //2020年7月24日 23:17到此
          that.writeUserInforToStorage(datas)
          //对用户的openid在数据库中的查询结果为0，说明用户已还未在数据库中注册
        }
        else if (result.data.objects.length == 0) {
          //查询不到该用户信息,向数据库中添加
          that.addDataToMinapp(that.data.tableID.user_info, (MyRecord) => {
            MyRecord.set({
              //初始化保存用户的openid以及一个13位的时间戳作为注册时间
              'user_openid': wx.BaaS.storage.get("openid"),
              'user_regtime': (new Date()).valueOf() + "",
            })
          }, (res) => {
            //201 创建成功，400 请求数据非法或超过最大操作条目数上限
            if (res.statusCode = 201) {
              console.log(res)
              that.writeUserInforToStorage(res.data)
            } else {

            }
          }, () => { })
          //用户身份信息不唯一，数据出错需要联系管理员
        } else {

        }
      })
    }

  },

  onLaunch: function () {
    const that = this
    wx.BaaS = requirePlugin('sdkPlugin')
    //让插件帮助完成登录、支付等功能
    wx.BaaS.wxExtend(wx.login,
      wx.getUserInfo,
      wx.requestPayment)
    wx.BaaS.init('fd00d547228f57071394')
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)
    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })

    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              // 可以将 res 发送给后台解码出 unionId
              this.globalData.userInfo = res.userInfo
              // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
              // 所以此处加入 callback 以防止这种情况
              if (this.userInfoReadyCallback) {
                this.userInfoReadyCallback(res)
              }
            }
          })
        } else {

        }
      }
    })

    //对用户的Session进行检查
    wx.checkSession({
      success: () => {
        // session_key 未过期，并且在本生命周期一直有效
      },
      fail: () => {
        // session_key 已经失效，需要重新执行登录流程
        wx.BaaS.login(false).then(res => {
          // 登录成功
          // console.log("重新登录成功")
        }, res => {
          // 登录失败
          console.log("重新登录失败")
        })
      }
    })

    //检测用户网络状态的变化，一旦激活就一直后台监测，一旦检测到网络状态发生变化就会进行相关的操作
    wx.onNetworkStatusChange(function (res) {
      //监测用户已经断开连接
      if (res.isConnected == false) {
        //网络断开后进行的操作
        console.log("网络错误")
      } else {
        console.log("网络改变，且正常")
      }
    })
    // 
    // that.checkStroageWhetherComplete()
    that.initialGetUserInfor()
  },

  globalData: {
    userInfo: null
  }
})